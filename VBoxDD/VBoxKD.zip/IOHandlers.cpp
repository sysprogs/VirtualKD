#include "stdafx.h"
#include "IOHandlers.h"
#include "../rpcdispatch/rpcdisp.h"
#include "../rpcdispatch/kdcomdisp.h"
#include "../rpcdispatch/reporter.h"

#include <VBox/vmm/mm.h>

int VirtualKDDevice::VirtualKDPortOutHandler( void *pvUser, RTIOPORT Port, uint32_t u32, unsigned cb )
{
	struct  
	{
		unsigned RequestSize;
		unsigned MaxReplySize;
	} RequestHeader = {0, };
	static char CmdBody[262144];
	if (Port == 0x5659)
	{
		int rc = PDMDevHlpPhysRead(m_pDevIns, (RTGCPHYS)u32, &RequestHeader, sizeof(RequestHeader));
		if (!RT_SUCCESS(rc) || !RequestHeader.RequestSize)
			return VINF_SUCCESS;
		rc = PDMDevHlpPhysRead(m_pDevIns, (RTGCPHYS)(u32 + sizeof(RequestHeader)), CmdBody, RequestHeader.RequestSize);
		if (!RT_SUCCESS(rc))
			return VINF_SUCCESS;
		ASSERT(!memcmp(CmdBody, g_szRPCCommandHeader, sizeof(g_szRPCCommandHeader) - 1));
		
		char *pReply = NULL;
		unsigned done = m_pKDClient ? m_pKDClient->OnRequest(CmdBody + sizeof(g_szRPCCommandHeader) - 1, RequestHeader.RequestSize - (sizeof(g_szRPCCommandHeader) - 1), &pReply) : 0;

		if (!pReply)
			done = 0;

		char Prefix[sizeof(done) + 2];
		((unsigned *)Prefix)[0] = done + 2;
		Prefix[sizeof(unsigned)] = '1';
		Prefix[sizeof(unsigned) + 1] = ' ';

		rc = PDMDevHlpPhysWrite(m_pDevIns, (RTGCPHYS)u32, Prefix, sizeof(Prefix));
		if (!RT_SUCCESS(rc))
			return VINF_SUCCESS;
		if (done)
		{
			rc = PDMDevHlpPhysWrite(m_pDevIns, (RTGCPHYS)(u32 + sizeof(Prefix)), pReply, done);
			if (!RT_SUCCESS(rc))
				return VINF_SUCCESS;
		}
		return VINF_SUCCESS;
	}
	else
	{
		if ((Port == 0x5658) && (u32 == 0x564D5868))
			m_bVMWareOpenChannelDetected = true;
		else
			m_bVMWareOpenChannelDetected = false;
		return VINF_SUCCESS;
	}
}

int VirtualKDDevice::VirtualKDPortInHandler( void *pvUser, RTIOPORT Port, uint32_t *pu32, unsigned cb )
{
	if (m_bVMWareOpenChannelDetected)
	{
		*pu32 = 'XOBV';	//Checked in VMWRPC.H
		m_bVMWareOpenChannelDetected = false;
		m_bChannelDetectSuccessful = true;
	}
	else
		*pu32 = -1;
	return VINF_SUCCESS;
}

int VirtualKDDevice::sVirtualKDPortInHandler( PPDMDEVINS pDevIns, void *pvUser, RTIOPORT Port, uint32_t *pu32, unsigned cb )
{
	VirtualKDDevice *pThis = PDMINS_2_DATA(pDevIns, VirtualKDDevice *);
	return pThis->VirtualKDPortInHandler(pvUser, Port, pu32, cb);
}

int VirtualKDDevice::sVirtualKDPortOutHandler( PPDMDEVINS pDevIns, void *pvUser, RTIOPORT Port, uint32_t u32, unsigned cb )
{
	VirtualKDDevice *pThis = PDMINS_2_DATA(pDevIns, VirtualKDDevice *);
	return pThis->VirtualKDPortOutHandler(pvUser, Port, u32, cb);
}

//-------------------------------------------------------------------------------------------------------------------------------------
#include <bzscore/path.h>
using namespace BazisLib;

int VirtualKDDevice::RegisterHandlers()
{
	int rc = PDMDevHlpIOPortRegister(m_pDevIns, 0x5658, 2, NULL,  &sVirtualKDPortOutHandler, &sVirtualKDPortInHandler, NULL, NULL, "VirtualKD interface");
	if (!RT_SUCCESS(rc))
		return rc;
	return VINF_SUCCESS;
}

VirtualKDDevice::~VirtualKDDevice()
{
	delete m_pKDClient;
	if (m_hKDClient)
		FreeLibrary(m_hKDClient);
}

VirtualKDDevice::VirtualKDDevice(PPDMDEVINS pDevIns) 
	: m_bVMWareOpenChannelDetected(false)
	, m_bChannelDetectSuccessful(false)
	, m_hKDClient(0)
	, m_pKDClient(NULL)
	, m_pDevIns(pDevIns)
{
	extern HINSTANCE g_hThisDll;

	TCHAR tszDLL[MAX_PATH] = {0,};
	GetModuleFileName(g_hThisDll, tszDLL, _countof(tszDLL));

#ifdef _WIN64
	TCHAR *pDLL = _T("kdclient64.dll");
#else
	TCHAR *pDLL = _T("kdclient.dll");
#endif

	String strKDClient = Path::Combine(Path::GetDirectoryName(TempStrPointerWrapper(tszDLL)), pDLL);

	m_hKDClient = LoadLibrary(strKDClient.c_str());
	if (m_hKDClient)
	{
		PCreateVBoxKDClient init = (PCreateVBoxKDClient)GetProcAddress(m_hKDClient, "CreateVBoxKDClient");
		if (init)
		{
			m_pKDClient = init();
			if (m_pKDClient)
				return;
		}
	}
	MessageBox(0, String::sFormat(_T("VirtualKD failed to load %s. Fast kernel-mode debugging won't work!"), strKDClient.c_str()).c_str(), NULL, MB_ICONERROR);
}

